sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("recipeui.controller.controller.App", {
        onInit() {
        }
      });
    }
  );
  